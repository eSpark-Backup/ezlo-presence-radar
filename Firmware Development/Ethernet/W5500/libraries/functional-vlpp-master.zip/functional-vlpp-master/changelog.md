# functional-vlpp Library


[![arduino-library-badge](https://www.ardu-badge.com/badge/FTP_Server_Teensy41.svg?)](https://www.ardu-badge.com/FTP_Server_Teensy41)
[![GitHub release](https://img.shields.io/github/release/khoih-prog/FTP_Server_Teensy41.svg)](https://github.com/khoih-prog/FTP_Server_Teensy41/releases)
[![contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](#Contributing)
[![GitHub issues](https://img.shields.io/github/issues/khoih-prog/FTP_Server_Teensy41.svg)](http://github.com/khoih-prog/FTP_Server_Teensy41/issues)


<a href="https://www.buymeacoffee.com/khoihprog6" title="Donate to my libraries using BuyMeACoffee"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Donate to my libraries using BuyMeACoffee" style="height: 50px !important;width: 181px !important;" ></a>
<a href="https://www.buymeacoffee.com/khoihprog6" title="Donate to my libraries using BuyMeACoffee"><img src="https://img.shields.io/badge/buy%20me%20a%20coffee-donate-orange.svg?logo=buy-me-a-coffee&logoColor=FFDD00" style="height: 20px !important;width: 200px !important;" ></a>


---
---

## Table of Contents


* [Changelog](#changelog)
  * [Release v1.0.2](#release-v102)
  * [Release v1.0.1](#release-v101)
  * [Release v1.0.0](#release-v100)

---
---

## Changelog

### Release v1.0.2

1. Clear compiler warnings.
2. Add Version String
3. Add Table of Contents

### Release v1.0.1

1. Add support to and tested working **OK** in other architectures such as **Teensy, SAM, SAMD, STM32, eps8266, esp32** besides AVR.

### Release v1.0.0

1. Based on and modified from [**Marcus Rugger's functional-vlpp Library**](https://github.com/marcusrugger/functional-vlpp).


